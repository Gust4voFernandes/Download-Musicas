"""Interface gráfica (CustomTkinter).

Regra de ouro: só a thread principal mexe nos widgets. O trabalho pesado roda
numa thread do `Gerenciador`, que manda `Evento`s para `self._eventos`
(uma queue.Queue). A cada 50 ms a interface consome essa fila.
"""

from __future__ import annotations

import logging
import queue
import threading
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from nucleo import __version__
from nucleo.configuracoes import QUALIDADES, Configuracoes
from nucleo.conversor import EXTENSOES_SUPORTADAS
from nucleo.entrada import ler_lista_txt
from nucleo.ferramentas import abrir_pasta, localizar_deno, localizar_ffmpeg, pasta_de_configuracao
from nucleo.gerenciador import Evento, Gerenciador, OpcoesDownload, TipoEvento
from nucleo.youtube import Etapa, Status

VERDE = "#2CC985"
AMARELO = "#E5B53B"
VERMELHO = "#E5534B"
AZUL = "#3B8ED0"
CINZA = "gray60"

TEXTO_STATUS = {
    Status.OK: ("✔ Concluído", VERDE),
    Status.JA_EXISTE: ("📁 Já existia", AZUL),
    Status.PULADO: ("⏭ Pulado", AMARELO),
    Status.CANCELADO: ("⛔ Cancelado", CINZA),
    Status.ERRO: ("✖ Erro", VERMELHO),
}

TEXTO_ETAPA = {
    Etapa.BAIXANDO: ("Baixando", AZUL),
    Etapa.CONVERTENDO: ("Convertendo para MP3…", AMARELO),
    Etapa.FINALIZANDO: ("Gravando capa e tags…", AMARELO),
}

log = logging.getLogger(__name__)

MAX_LINHAS_VISIVEIS = 400  # acima disso o Tk fica lento; os demais seguem sendo baixados


def _encurtar(texto: str, limite: int = 70) -> str:
    return texto if len(texto) <= limite else texto[: limite - 1] + "…"


class LinhaItem(ctk.CTkFrame):
    """Uma música no histórico: título, status e barra de progresso."""

    def __init__(self, mestre, titulo: str) -> None:
        super().__init__(mestre, corner_radius=8)
        self.grid_columnconfigure(0, weight=1)

        self.lbl_titulo = ctk.CTkLabel(self, text=_encurtar(titulo), anchor="w", font=ctk.CTkFont(size=12, weight="bold"))
        self.lbl_titulo.grid(row=0, column=0, sticky="ew", padx=10, pady=(6, 0))

        self.lbl_status = ctk.CTkLabel(self, text="Na fila", anchor="e", text_color=CINZA, font=ctk.CTkFont(size=11))
        self.lbl_status.grid(row=0, column=1, sticky="e", padx=10, pady=(6, 0))

        self.barra = ctk.CTkProgressBar(self, height=8)
        self.barra.set(0)
        self.barra.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=(4, 8))

    def definir_titulo(self, titulo: str) -> None:
        self.lbl_titulo.configure(text=_encurtar(titulo))

    def definir_etapa(self, etapa: Etapa, fracao: float | None) -> None:
        texto, cor = TEXTO_ETAPA[etapa]
        if etapa == Etapa.BAIXANDO and fracao is not None:
            self.barra.set(fracao)
            texto = f"{texto} {int(fracao * 100)}%"
        elif etapa != Etapa.BAIXANDO:
            self.barra.set(1)
        self.lbl_status.configure(text=texto, text_color=cor)

    def finalizar(self, status: Status, mensagem: str = "") -> None:
        texto, cor = TEXTO_STATUS[status]
        if mensagem and status == Status.ERRO:
            texto = f"{texto}: {_encurtar(mensagem, 60)}"
        self.lbl_status.configure(text=texto, text_color=cor)
        self.lbl_titulo.configure(text_color=cor if status in (Status.OK, Status.ERRO) else None)
        self.barra.set(1 if status in (Status.OK, Status.JA_EXISTE) else 0)


class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        self.title(f"Baixador de Músicas — Gustavo Engineering v{__version__}")
        self.geometry("780x760")
        self.minsize(640, 600)

        self.cfg = Configuracoes.carregar()
        self._eventos: queue.Queue[Evento] = queue.Queue()
        self.gerenciador = Gerenciador(self._eventos.put)
        self.linhas: dict[int, LinhaItem] = {}
        self.total_atual = 0
        self.concluidos = 0

        self._criar_interface()
        self._verificar_dependencias()
        self.protocol("WM_DELETE_WINDOW", self._ao_fechar)
        self.bind("<Control-Return>", lambda _e: self.iniciar_download())
        self.after(50, self._consumir_eventos)

    # ------------------------------------------------------------------ layout
    def _criar_interface(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(5, weight=1)

        # Cabeçalho
        topo = ctk.CTkFrame(self, fg_color="transparent")
        topo.grid(row=0, column=0, sticky="ew", padx=20, pady=(16, 4))
        topo.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(topo, text="🎵 Baixador de Músicas", font=ctk.CTkFont(size=24, weight="bold")).grid(
            row=0, column=0, sticky="w"
        )
        ctk.CTkButton(topo, text="?", width=32, height=32, corner_radius=16, fg_color="#444", hover_color="#666",
                      command=self.abrir_ajuda).grid(row=0, column=1, sticky="e")

        # Entrada
        caixa = ctk.CTkFrame(self)
        caixa.grid(row=1, column=0, sticky="ew", padx=20, pady=6)
        caixa.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(caixa, text="Links, nomes de músicas ou playlists — um por linha:", anchor="w").grid(
            row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 2)
        )
        self.txt_entrada = ctk.CTkTextbox(caixa, height=90, wrap="none")
        self.txt_entrada.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10)
        botoes = ctk.CTkFrame(caixa, fg_color="transparent")
        botoes.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=8)
        ctk.CTkButton(botoes, text="📄 Importar .txt", width=130, fg_color="#555", hover_color="#333",
                      command=self.importar_txt).pack(side="left")
        ctk.CTkButton(botoes, text="🔄 Converter arquivos do PC…", width=200, fg_color="#555", hover_color="#333",
                      command=self.converter_arquivos).pack(side="left", padx=8)
        ctk.CTkButton(botoes, text="Limpar", width=70, fg_color="transparent", border_width=1,
                      command=lambda: self.txt_entrada.delete("1.0", "end")).pack(side="right")

        # Configurações
        conf = ctk.CTkFrame(self)
        conf.grid(row=2, column=0, sticky="ew", padx=20, pady=6)
        conf.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(conf, text="📂 Pasta", width=90, command=self.selecionar_pasta).grid(
            row=0, column=0, padx=(10, 6), pady=(10, 4)
        )
        self.lbl_pasta = ctk.CTkLabel(conf, text="", anchor="w", text_color=CINZA)
        self.lbl_pasta.grid(row=0, column=1, sticky="ew", pady=(10, 4))
        ctk.CTkButton(conf, text="Abrir", width=60, fg_color="transparent", border_width=1,
                      command=lambda: abrir_pasta(self.cfg.pasta_download)).grid(row=0, column=2, padx=10, pady=(10, 4))
        self._atualizar_rotulo_pasta()

        opcoes = ctk.CTkFrame(conf, fg_color="transparent")
        opcoes.grid(row=1, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 10))
        ctk.CTkLabel(opcoes, text="Qualidade (kbps):").pack(side="left")
        self.combo_qualidade = ctk.CTkOptionMenu(opcoes, values=list(QUALIDADES), width=80,
                                                 command=self._salvar_opcoes)
        self.combo_qualidade.set(self.cfg.qualidade)
        self.combo_qualidade.pack(side="left", padx=(6, 18))
        self.var_capa = ctk.BooleanVar(value=self.cfg.capa_e_metadados)
        ctk.CTkCheckBox(opcoes, text="Capa e tags no MP3", variable=self.var_capa,
                        command=self._salvar_opcoes).pack(side="left", padx=(0, 18))
        self.var_pular = ctk.BooleanVar(value=self.cfg.pular_existentes)
        ctk.CTkCheckBox(opcoes, text="Pular músicas que já estão na pasta", variable=self.var_pular,
                        command=self._salvar_opcoes).pack(side="left")

        # Ações
        acoes = ctk.CTkFrame(self, fg_color="transparent")
        acoes.grid(row=3, column=0, pady=8)
        self.btn_iniciar = ctk.CTkButton(acoes, text="⬇ BAIXAR EM MP3", width=200, height=42,
                                         font=ctk.CTkFont(size=14, weight="bold"), fg_color="#1f8a4c",
                                         hover_color="#166b3a", command=self.iniciar_download)
        self.btn_iniciar.grid(row=0, column=0, padx=6)
        self.btn_pular = ctk.CTkButton(acoes, text="⏭ Pular atual", width=130, height=42, fg_color="#9a6b00",
                                       hover_color="#6e4c00", state="disabled", command=self.pular_atual)
        self.btn_pular.grid(row=0, column=1, padx=6)
        self.btn_cancelar = ctk.CTkButton(acoes, text="⛔ Cancelar tudo", width=140, height=42, fg_color="#b33a3a",
                                          hover_color="#7d2828", state="disabled", command=self.cancelar_tudo)
        self.btn_cancelar.grid(row=0, column=2, padx=6)

        # Progresso geral
        geral = ctk.CTkFrame(self, fg_color="transparent")
        geral.grid(row=4, column=0, sticky="ew", padx=20)
        geral.grid_columnconfigure(0, weight=1)
        self.lbl_contador = ctk.CTkLabel(geral, text="", anchor="w", font=ctk.CTkFont(size=13, weight="bold"),
                                         text_color=AZUL)
        self.lbl_contador.grid(row=0, column=0, sticky="w")
        ctk.CTkButton(geral, text="Limpar histórico", width=110, height=24, fg_color="transparent", border_width=1,
                      command=self.limpar_historico).grid(row=0, column=1, sticky="e")
        self.barra_geral = ctk.CTkProgressBar(geral, height=10)
        self.barra_geral.set(0)
        self.barra_geral.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(4, 0))

        # Histórico
        self.scroll = ctk.CTkScrollableFrame(self, label_text="Histórico")
        self.scroll.grid(row=5, column=0, sticky="nsew", padx=20, pady=8)
        self.scroll.grid_columnconfigure(0, weight=1)

        # Rodapé
        self.lbl_status = ctk.CTkLabel(self, text="Pronto.", anchor="w", text_color=CINZA)
        self.lbl_status.grid(row=6, column=0, sticky="ew", padx=20, pady=(0, 4))
        self.lbl_deps = ctk.CTkLabel(self, text="", anchor="w", font=ctk.CTkFont(size=11))
        self.lbl_deps.grid(row=7, column=0, sticky="ew", padx=20, pady=(0, 10))

    def _verificar_dependencias(self) -> None:
        ffmpeg, deno = localizar_ffmpeg(), localizar_deno()
        log.info("Iniciando v%s | FFmpeg: %s | Deno: %s", __version__, ffmpeg, deno)
        if not ffmpeg:
            self.lbl_deps.configure(text="⚠ FFmpeg não encontrado: não dá para converter para MP3. Clique em ? para ver como resolver.",
                                    text_color=VERMELHO)
        elif not deno:
            self.lbl_deps.configure(text="FFmpeg OK · Deno não encontrado (opcional, ajuda com o YouTube — veja a Ajuda)",
                                    text_color=AMARELO)
        else:
            self.lbl_deps.configure(text="FFmpeg OK · Deno OK", text_color=VERDE)

    # ----------------------------------------------------------- ações
    def _texto_entrada(self) -> str:
        return self.txt_entrada.get("1.0", "end").strip()

    def _opcoes(self) -> OpcoesDownload:
        return OpcoesDownload(
            pasta=self.cfg.pasta_download,
            qualidade=self.combo_qualidade.get(),
            capa_e_metadados=self.var_capa.get(),
            pular_existentes=self.var_pular.get(),
        )

    def iniciar_download(self) -> None:
        if self.gerenciador.ocupado:
            return
        entrada = self._texto_entrada()
        if not entrada:
            self._status("⚠️ Cole um link, digite o nome de uma música ou importe um .txt.", AMARELO)
            return
        self._comecar_trabalho()
        threading.Thread(target=self.gerenciador.baixar, args=(entrada, self._opcoes()), daemon=True).start()

    def converter_arquivos(self) -> None:
        if self.gerenciador.ocupado:
            return
        padroes = " ".join(f"*{ext}" for ext in EXTENSOES_SUPORTADAS)
        arquivos = filedialog.askopenfilenames(
            title="Escolha os arquivos para converter em MP3",
            filetypes=[("Áudio e vídeo", padroes), ("Todos os arquivos", "*.*")],
        )
        if not arquivos:
            return
        mesma_pasta = messagebox.askyesno(
            "Onde salvar?",
            "Salvar os MP3 na MESMA pasta dos arquivos originais?\n\n"
            f"(Não = salvar em {self.cfg.pasta_download})",
        )
        destino = None if mesma_pasta else self.cfg.pasta_download
        self._comecar_trabalho()
        threading.Thread(
            target=self.gerenciador.converter,
            args=(list(arquivos), destino, self.combo_qualidade.get()),
            daemon=True,
        ).start()

    def pular_atual(self) -> None:
        self.gerenciador.pular_atual()
        self._status("⏭ Pulando a música atual…", AMARELO)

    def cancelar_tudo(self) -> None:
        self.gerenciador.cancelar_tudo()
        self.btn_cancelar.configure(state="disabled")
        self.btn_pular.configure(state="disabled")
        self._status("⛔ Cancelando… (o arquivo atual será descartado)", VERMELHO)

    def importar_txt(self) -> None:
        caminho = filedialog.askopenfilename(filetypes=[("Arquivos de texto", "*.txt")])
        if not caminho:
            return
        try:
            linhas = ler_lista_txt(caminho)
        except OSError as e:
            self._status(f"❌ Não consegui ler o arquivo: {e}", VERMELHO)
            return
        atual = self._texto_entrada()
        self.txt_entrada.delete("1.0", "end")
        self.txt_entrada.insert("1.0", "\n".join(([atual] if atual else []) + linhas))
        self._status(f"📄 {len(linhas)} item(ns) importado(s) de {Path(caminho).name}.", VERDE)

    def selecionar_pasta(self) -> None:
        pasta = filedialog.askdirectory(initialdir=self.cfg.pasta_download)
        if pasta:
            self.cfg.pasta_download = pasta
            self.cfg.salvar()
            self._atualizar_rotulo_pasta()

    def limpar_historico(self) -> None:
        if self.gerenciador.ocupado:
            return
        for linha in self.linhas.values():
            linha.destroy()
        self.linhas.clear()
        self.lbl_contador.configure(text="")
        self.barra_geral.set(0)

    # ------------------------------------------------------- eventos
    def _consumir_eventos(self) -> None:
        try:
            for _ in range(200):  # limita o trabalho por "tick" para a janela não travar
                self._tratar_evento(self._eventos.get_nowait())
        except queue.Empty:
            pass
        self.after(50, self._consumir_eventos)

    def _tratar_evento(self, ev: Evento) -> None:
        if ev.tipo == TipoEvento.MENSAGEM:
            self._status(ev.mensagem)

        elif ev.tipo == TipoEvento.FILA:
            self.limpar_historico_forcado()
            self.total_atual, self.concluidos = ev.total, 0
            for i, titulo in enumerate(ev.titulos[:MAX_LINHAS_VISIVEIS]):
                linha = LinhaItem(self.scroll, titulo)
                linha.grid(row=i, column=0, sticky="ew", pady=3, padx=2)
                self.linhas[i] = linha
            extra = ev.total - len(self.linhas)
            self._status(f"{ev.total} item(ns) na fila" + (f" (mostrando os {len(self.linhas)} primeiros)" if extra > 0 else "") + ".")
            self._atualizar_contador()

        elif ev.tipo == TipoEvento.INICIO_ITEM:
            self.lbl_contador.configure(text=f"Item {ev.indice + 1} de {ev.total}: {_encurtar(ev.titulo, 55)}")
            if linha := self.linhas.get(ev.indice):
                linha.lbl_status.configure(text="Iniciando…", text_color=AZUL)
                self._rolar_ate(ev.indice)

        elif ev.tipo == TipoEvento.TITULO_ITEM:
            if linha := self.linhas.get(ev.indice):
                linha.definir_titulo(ev.titulo)

        elif ev.tipo == TipoEvento.PROGRESSO_ITEM and ev.etapa:
            if linha := self.linhas.get(ev.indice):
                linha.definir_etapa(ev.etapa, ev.progresso)

        elif ev.tipo == TipoEvento.FIM_ITEM and ev.resultado:
            self.concluidos += 1
            if linha := self.linhas.get(ev.indice):
                linha.finalizar(ev.resultado.status, ev.resultado.mensagem)
            self._atualizar_contador()

        elif ev.tipo == TipoEvento.FIM:
            self._terminar_trabalho(ev.mensagem)

    def limpar_historico_forcado(self) -> None:
        for linha in self.linhas.values():
            linha.destroy()
        self.linhas.clear()

    def _rolar_ate(self, indice: int) -> None:
        if len(self.linhas) > 1:
            try:
                self.scroll._parent_canvas.yview_moveto(max(0.0, (indice - 2) / len(self.linhas)))
            except Exception:
                pass  # atributo interno do CustomTkinter; se mudar, só não rola sozinho

    def _atualizar_contador(self) -> None:
        if self.total_atual:
            self.barra_geral.set(self.concluidos / self.total_atual)

    # ------------------------------------------------------- estado
    def _comecar_trabalho(self) -> None:
        self.btn_iniciar.configure(state="disabled", text="Trabalhando…")
        self.btn_pular.configure(state="normal")
        self.btn_cancelar.configure(state="normal")
        self.barra_geral.set(0)
        self._status("Preparando…", AZUL)

    def _terminar_trabalho(self, resumo: str) -> None:
        self.btn_iniciar.configure(state="normal", text="⬇ BAIXAR EM MP3")
        self.btn_pular.configure(state="disabled")
        self.btn_cancelar.configure(state="disabled")
        self.lbl_contador.configure(text="Finalizado." if self.total_atual else "")
        falhou = resumo.startswith(("❌", "⚠"))
        teve_erro = "com erro" in resumo
        self._status(resumo, VERMELHO if falhou else AMARELO if teve_erro else VERDE)
        if self.concluidos and not falhou and not teve_erro:
            self.txt_entrada.delete("1.0", "end")  # só limpa se tudo deu certo

    def _status(self, texto: str, cor: str = CINZA) -> None:
        self.lbl_status.configure(text=texto, text_color=cor)

    def _atualizar_rotulo_pasta(self) -> None:
        pasta = self.cfg.pasta_download
        self.lbl_pasta.configure(text=pasta if len(pasta) <= 60 else "…" + pasta[-59:])

    def _salvar_opcoes(self, *_args) -> None:
        self.cfg.qualidade = self.combo_qualidade.get()
        self.cfg.capa_e_metadados = self.var_capa.get()
        self.cfg.pular_existentes = self.var_pular.get()
        self.cfg.salvar()

    def _ao_fechar(self) -> None:
        if self.gerenciador.ocupado and not messagebox.askyesno(
            "Sair?", "Ainda há downloads em andamento. Deseja cancelar e sair?"
        ):
            return
        self.gerenciador.cancelar_tudo()
        self._salvar_opcoes()
        self.destroy()

    # ------------------------------------------------------- ajuda
    def abrir_ajuda(self) -> None:
        janela = ctk.CTkToplevel(self)
        janela.title("Ajuda")
        janela.geometry("600x560")
        janela.transient(self)
        janela.after(100, janela.lift)

        ffmpeg = localizar_ffmpeg() or "NÃO ENCONTRADO"
        deno = localizar_deno() or "não encontrado (opcional)"
        texto = f"""COMO USAR
• Cole na caixa um link por linha (vídeo, playlist, YouTube Music) ou
  simplesmente o nome da música: "Guns N Roses - Patience".
• Pode misturar links e nomes. Linhas começando com # são ignoradas.
• Links de "Mix"/Rádio do YouTube (list=RD...) baixam só a música do link.
• Ctrl+Enter também inicia o download.

LISTA EM .TXT
Crie um .txt no Bloco de Notas com uma música ou link por linha e use
"Importar .txt". O conteúdo aparece na caixa para você revisar.

CONVERTER ARQUIVOS DO PC
"Converter arquivos do PC…" transforma .mp4, .m4a, .webm, .wav, .flac,
.ogg etc. em MP3 na qualidade escolhida.

PASTA DE DESTINO
{self.cfg.pasta_download}

FFMPEG (obrigatório para gerar MP3)
{ffmpeg}
Se não foi encontrado: instale com  winget install Gyan.FFmpeg
ou coloque ffmpeg.exe ao lado do programa (ou na pasta vendor/).

DENO (opcional, recomendado)
{deno}
O YouTube passou a exigir um runtime JavaScript para liberar alguns
formatos. Instale com  winget install DenoLand.Deno  se aparecerem erros
de "formato indisponível" ou 403.

PROBLEMAS?
1) Atualize o yt-dlp:  pip install -U "yt-dlp[default]"
2) Veja o log detalhado em:
   {pasta_de_configuracao() / 'baixador.log'}

Use apenas com conteúdo que você tem direito de baixar."""
        caixa = ctk.CTkTextbox(janela, wrap="word", font=ctk.CTkFont(family="Consolas", size=12))
        caixa.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        caixa.insert("1.0", texto)
        caixa.configure(state="disabled")
        ctk.CTkButton(janela, text="Entendi", width=110, command=janela.destroy).pack(pady=(0, 14))
