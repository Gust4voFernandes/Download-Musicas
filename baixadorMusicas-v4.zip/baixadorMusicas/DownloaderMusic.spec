# -*- mode: python ; coding: utf-8 -*-
# Gera um único DownloaderMusic.exe com tudo dentro (CustomTkinter, yt-dlp e FFmpeg).
# Uso:  python -m PyInstaller --noconfirm --clean DownloaderMusic.spec
import os
from pathlib import Path

from PyInstaller.utils.hooks import collect_all

datas, binaries, hiddenimports = [], [], []
for pacote in ("customtkinter", "yt_dlp", "yt_dlp_ejs", "imageio_ffmpeg"):
    try:
        d, b, h = collect_all(pacote)
        datas += d; binaries += b; hiddenimports += h
    except Exception as erro:
        print(f"[spec] aviso: não consegui coletar {pacote}: {erro}")

# Binários opcionais colocados em vendor/ (ffmpeg.exe, deno.exe...)
sufixo = ".exe" if os.name == "nt" else ""
for nome in ("ffmpeg", "ffprobe", "deno"):
    arquivo = Path("vendor") / f"{nome}{sufixo}"
    if arquivo.is_file():
        print(f"[spec] embutindo {arquivo}")
        binaries.append((str(arquivo), "."))

a = Analysis(
    ["principal.py"],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "numpy", "matplotlib", "PIL.ImageQt"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="DownloaderMusic",
    icon="icone.ico" if Path("icone.ico").is_file() else None,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,  # UPX costuma gerar falso positivo em antivírus
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
