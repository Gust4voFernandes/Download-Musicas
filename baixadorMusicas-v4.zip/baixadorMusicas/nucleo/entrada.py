"""Interpreta o que o usuário digitou: links, nomes de músicas ou arquivos .txt.

Funções puras (sem rede e sem interface), por isso são fáceis de testar.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlparse

_RE_URL = re.compile(r"^https?://", re.IGNORECASE)
_PREFIXOS_SEM_ESQUEMA = ("www.", "youtube.com", "youtu.be", "music.youtube.com", "m.youtube.com")


@dataclass(frozen=True)
class Alvo:
    """Uma coisa que o usuário pediu para baixar."""

    texto: str  # o que foi digitado (serve de título provisório)
    url: str  # URL ou "ytsearch1:..." que vai para o yt-dlp
    eh_busca: bool  # True quando é um nome de música, não um link


def eh_url(texto: str) -> bool:
    t = texto.strip()
    return bool(_RE_URL.match(t)) or t.lower().startswith(_PREFIXOS_SEM_ESQUEMA)


def normalizar_url(url: str) -> str:
    url = url.strip()
    return url if _RE_URL.match(url) else "https://" + url


def eh_youtube(url: str) -> bool:
    host = urlparse(url).netloc.lower().split(":")[0]
    return any(host == h or host.endswith("." + h) for h in ("youtube.com", "youtu.be"))


def tratar_link_youtube(url: str) -> str:
    """Ajusta links do YouTube que têm `list=`.

    - `watch?v=X&list=PL...`  -> playlist completa (comportamento da v3)
    - `watch?v=X&list=RD...`  -> só o vídeo X. Listas "RD" são Mix/Rádio gerados
      automaticamente, quase infinitos; baixar tudo raramente é o que se quer.
    """
    if not eh_youtube(url):
        return url

    partes = urlparse(url)
    parametros = parse_qs(partes.query)
    lista = (parametros.get("list") or [None])[0]
    if not lista:
        return url

    if lista.startswith("RD"):
        video = (parametros.get("v") or [None])[0]
        if not video and "youtu.be" in partes.netloc:
            video = partes.path.strip("/") or None
        return f"https://www.youtube.com/watch?v={video}" if video else url

    host = "music.youtube.com" if partes.netloc.lower().startswith("music.") else "www.youtube.com"
    return f"https://{host}/playlist?list={lista}"


def ler_lista_txt(caminho: str | Path) -> list[str]:
    """Lê um .txt com uma música/link por linha.

    - Aceita UTF-8 (com ou sem BOM) e ANSI/Windows-1252 (Bloco de Notas antigo).
    - Ignora linhas vazias e comentários iniciados com '#'.
    - Remove duplicadas mantendo a ordem.
    """
    dados = Path(caminho).read_bytes()
    texto = ""
    for codificacao in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            texto = dados.decode(codificacao)
            break
        except UnicodeDecodeError:
            continue
    return _limpar_linhas(texto.splitlines())


def _limpar_linhas(linhas: list[str]) -> list[str]:
    resultado: list[str] = []
    vistos: set[str] = set()
    for linha in linhas:
        item = linha.strip()
        if not item or item.startswith("#"):
            continue
        chave = item.casefold()
        if chave in vistos:
            continue
        vistos.add(chave)
        resultado.append(item)
    return resultado


def interpretar_linha(linha: str) -> Alvo:
    linha = linha.strip()
    if eh_url(linha):
        return Alvo(texto=linha, url=tratar_link_youtube(normalizar_url(linha)), eh_busca=False)
    return Alvo(texto=linha, url=f"ytsearch1:{linha}", eh_busca=True)


def interpretar_entrada(entrada: str) -> list[Alvo]:
    """Converte o conteúdo da caixa de texto em uma lista de alvos.

    Cada linha pode ser um link, um nome de música ou o caminho de um .txt.
    Lança ValueError se um .txt informado não existir.
    """
    alvos: list[Alvo] = []
    for linha in _limpar_linhas(entrada.splitlines()):
        linha = linha.strip().strip('"')
        if linha.lower().endswith(".txt") and not eh_url(linha):
            if not Path(linha).is_file():
                raise ValueError(f"Arquivo não encontrado: {linha}")
            alvos.extend(interpretar_linha(item) for item in ler_lista_txt(linha))
        else:
            alvos.append(interpretar_linha(linha))

    # Remove repetidos que vieram de fontes diferentes (ex.: texto + .txt)
    unicos: dict[str, Alvo] = {}
    for alvo in alvos:
        unicos.setdefault(alvo.url.casefold(), alvo)
    return list(unicos.values())
