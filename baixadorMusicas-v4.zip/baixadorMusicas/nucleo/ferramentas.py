"""Localiza programas externos (FFmpeg, Deno) e pastas do sistema.

Ordem de busca de um executável:
  1. Dentro do .exe gerado pelo PyInstaller (sys._MEIPASS)
  2. Na pasta do programa (ao lado do .exe ou na raiz do projeto), inclusive
     nas subpastas `vendor/`, `ffmpeg/`, `ffmpeg/bin/` e `bin/`
  3. No PATH do sistema
  4. Nos pacotes pip `imageio-ffmpeg` (FFmpeg) e `deno` (Deno)
"""

from __future__ import annotations

import functools
import os
import shutil
import subprocess
import sys
from pathlib import Path

NO_WINDOWS = os.name == "nt"

# Evita que uma janela preta de console pisque ao chamar o FFmpeg no Windows.
FLAGS_SUBPROCESSO = getattr(subprocess, "CREATE_NO_WINDOW", 0) if NO_WINDOWS else 0


def pasta_do_programa() -> Path:
    """Pasta do .exe (quando empacotado) ou raiz do projeto (quando rodando o .py)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _pastas_de_busca() -> list[Path]:
    pastas: list[Path] = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        pastas.append(Path(meipass))
    base = pasta_do_programa()
    for sub in ("", "vendor", "vendor/ffmpeg/bin", "ffmpeg", "ffmpeg/bin", "bin"):
        pastas.append(base / sub if sub else base)
    return pastas


def _procurar_executavel(nome: str) -> str | None:
    arquivo = nome + (".exe" if NO_WINDOWS else "")
    for pasta in _pastas_de_busca():
        candidato = pasta / arquivo
        if candidato.is_file():
            return str(candidato)
    return shutil.which(nome)


@functools.lru_cache(maxsize=1)
def localizar_ffmpeg() -> str | None:
    """Caminho do FFmpeg, ou None se não houver nenhum disponível."""
    achado = _procurar_executavel("ffmpeg")
    if achado:
        return achado
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


@functools.lru_cache(maxsize=1)
def localizar_deno() -> str | None:
    """Caminho do Deno (runtime JavaScript que o yt-dlp usa no YouTube), se houver."""
    achado = _procurar_executavel("deno")
    if achado:
        return achado
    try:
        from deno import find_deno_bin

        caminho = find_deno_bin()
        return caminho if caminho and Path(caminho).is_file() else None
    except Exception:
        return None


def pasta_musicas_padrao() -> Path:
    """~/Music/Baixador de Musicas (ou ~/Baixador de Musicas se não houver 'Music')."""
    casa = Path.home()
    musicas = casa / "Music"
    return (musicas if musicas.is_dir() else casa) / "Baixador de Musicas"


def pasta_de_configuracao() -> Path:
    if NO_WINDOWS:
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
        pasta = base / "BaixadorMusicas"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
        pasta = base / "baixador-musicas"
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta


def abrir_pasta(caminho: str | Path) -> None:
    caminho = Path(caminho)
    caminho.mkdir(parents=True, exist_ok=True)
    if NO_WINDOWS:
        os.startfile(caminho)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(caminho)])
    else:
        subprocess.Popen(["xdg-open", str(caminho)])
