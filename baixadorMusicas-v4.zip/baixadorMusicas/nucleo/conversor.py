"""Converte arquivos de áudio/vídeo que já estão no computador para MP3."""

from __future__ import annotations

import subprocess
from pathlib import Path

from nucleo.ferramentas import FLAGS_SUBPROCESSO, localizar_ffmpeg

EXTENSOES_SUPORTADAS = (
    ".mp4", ".m4a", ".webm", ".mkv", ".mov", ".avi", ".flv", ".3gp",
    ".opus", ".ogg", ".oga", ".wav", ".flac", ".aac", ".wma", ".aiff", ".mp3",
)


class ErroConversao(Exception):
    pass


def destino_mp3(origem: Path, pasta_destino: Path | None = None) -> Path:
    pasta = pasta_destino or origem.parent
    destino = pasta / f"{origem.stem}.mp3"
    if destino.resolve() == origem.resolve():  # origem já é .mp3 na mesma pasta
        destino = pasta / f"{origem.stem} (convertido).mp3"
    return destino


def converter_para_mp3(
    origem: str | Path,
    pasta_destino: str | Path | None = None,
    qualidade: str = "192",
    sobrescrever: bool = False,
) -> Path:
    """Converte `origem` para MP3 e devolve o caminho do arquivo gerado.

    Lança FileExistsError se o destino já existir (e `sobrescrever` for False)
    e ErroConversao se o FFmpeg falhar ou não existir.
    """
    ffmpeg = localizar_ffmpeg()
    if not ffmpeg:
        raise ErroConversao("FFmpeg não encontrado. Veja o README.")

    origem = Path(origem)
    if not origem.is_file():
        raise ErroConversao(f"Arquivo não encontrado: {origem}")

    pasta = Path(pasta_destino) if pasta_destino else None
    if pasta:
        pasta.mkdir(parents=True, exist_ok=True)
    destino = destino_mp3(origem, pasta)
    if destino.exists() and not sobrescrever:
        raise FileExistsError(destino)

    comando = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
        "-y" if sobrescrever else "-n",
        "-i", str(origem),
        "-vn",                       # descarta o vídeo
        "-map_metadata", "0",        # mantém título/artista se existirem
        "-codec:a", "libmp3lame",
        "-b:a", f"{qualidade}k",
        "-id3v2_version", "3",       # tags legíveis no Windows Explorer e em carros
        str(destino),
    ]
    processo = subprocess.run(
        comando,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=FLAGS_SUBPROCESSO,
    )
    if processo.returncode != 0:
        if destino.exists():
            destino.unlink(missing_ok=True)
        linhas = [l for l in processo.stderr.strip().splitlines() if l.strip()]
        raise ErroConversao(linhas[-1] if linhas else f"FFmpeg terminou com código {processo.returncode}")
    return destino
