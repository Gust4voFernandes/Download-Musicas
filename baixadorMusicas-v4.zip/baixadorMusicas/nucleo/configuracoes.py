"""Guarda as preferências do usuário (pasta, qualidade...) entre execuções."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, fields
from pathlib import Path

from nucleo.ferramentas import pasta_de_configuracao, pasta_musicas_padrao

log = logging.getLogger(__name__)

QUALIDADES = ("128", "192", "256", "320")


@dataclass
class Configuracoes:
    pasta_download: str = ""
    qualidade: str = "192"
    capa_e_metadados: bool = True
    pular_existentes: bool = True

    def __post_init__(self) -> None:
        if not self.pasta_download:
            self.pasta_download = str(pasta_musicas_padrao())
        if self.qualidade not in QUALIDADES:
            self.qualidade = "192"

    @staticmethod
    def arquivo() -> Path:
        return pasta_de_configuracao() / "config.json"

    @classmethod
    def carregar(cls) -> "Configuracoes":
        try:
            dados = json.loads(cls.arquivo().read_text(encoding="utf-8"))
            validos = {f.name for f in fields(cls)}
            return cls(**{k: v for k, v in dados.items() if k in validos})
        except FileNotFoundError:
            return cls()
        except Exception:
            log.warning("config.json inválido; usando valores padrão", exc_info=True)
            return cls()

    def salvar(self) -> None:
        try:
            self.arquivo().write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            log.warning("Não foi possível salvar as configurações", exc_info=True)
