"""Tudo que fala com o yt-dlp: listar playlists e baixar uma música em MP3."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable, Optional

import yt_dlp
from yt_dlp.utils import DownloadCancelled, DownloadError

from nucleo.ferramentas import localizar_deno, localizar_ffmpeg

log = logging.getLogger(__name__)

TITULOS_INVALIDOS = {"[private video]", "[deleted video]", "[unavailable video]"}


class Status(Enum):
    OK = "ok"
    JA_EXISTE = "ja_existe"
    PULADO = "pulado"
    CANCELADO = "cancelado"
    ERRO = "erro"


class Etapa(Enum):
    BAIXANDO = "baixando"
    CONVERTENDO = "convertendo"
    FINALIZANDO = "finalizando"


@dataclass(frozen=True)
class ItemFila:
    titulo: str
    url: str


@dataclass(frozen=True)
class Resultado:
    status: Status
    titulo: str = ""
    caminho: Optional[Path] = None
    mensagem: str = ""


class ErroLeitura(Exception):
    """Não foi possível ler um link/playlist."""


class Interrompido(DownloadCancelled):
    """Levantada dentro dos hooks para parar o download atual."""

    def __init__(self, motivo: str) -> None:
        super().__init__(f"Interrompido: {motivo}")
        self.motivo = motivo  # "pular" ou "cancelar"


class _Logger:
    """Redireciona as mensagens do yt-dlp para o `logging` e guarda o último erro.

    Usar um logger próprio também evita que o yt-dlp escreva em stdout/stderr,
    que não existem no .exe sem console.
    """

    def __init__(self) -> None:
        self.ultimo_erro: str | None = None

    def debug(self, msg: str) -> None:
        log.debug(msg)

    def info(self, msg: str) -> None:
        log.info(msg)

    def warning(self, msg: str) -> None:
        log.warning(msg)

    def error(self, msg: str) -> None:
        self.ultimo_erro = msg
        log.error(msg)


def _opcoes_base(logger: _Logger) -> dict:
    opcoes: dict = {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "logger": logger,
        "socket_timeout": 20,
        "retries": 5,
        "fragment_retries": 5,
        "windowsfilenames": True,
    }
    ffmpeg = localizar_ffmpeg()
    if ffmpeg:
        opcoes["ffmpeg_location"] = ffmpeg
    deno = localizar_deno()
    if deno:
        opcoes["js_runtimes"] = {"deno": {"path": deno}}
    return opcoes


def mensagem_amigavel(erro: str | None) -> str:
    """Traduz os erros mais comuns do yt-dlp para algo que o usuário entenda."""
    if not erro:
        return "Erro desconhecido."
    texto = erro.replace("ERROR: ", "").strip()
    baixo = texto.lower()
    traducoes = [
        ("confirm you’re not a bot", "O YouTube pediu verificação anti-robô. Espere um pouco ou atualize o yt-dlp."),
        ("confirm you're not a bot", "O YouTube pediu verificação anti-robô. Espere um pouco ou atualize o yt-dlp."),
        ("confirm your age", "Vídeo com restrição de idade (exige login)."),
        ("private video", "Vídeo privado."),
        ("video unavailable", "Vídeo indisponível."),
        ("not available in your country", "Vídeo bloqueado no seu país."),
        ("members-only", "Conteúdo exclusivo para membros do canal."),
        ("http error 403", "O YouTube recusou o download (403). Atualize o yt-dlp."),
        ("ffmpeg", "FFmpeg não encontrado ou falhou na conversão. Veja o README."),
        ("ffprobe", "FFmpeg não encontrado ou falhou na conversão. Veja o README."),
        ("timed out", "Tempo de conexão esgotado. Verifique sua internet."),
        ("getaddrinfo failed", "Sem conexão com a internet."),
        ("name or service not known", "Sem conexão com a internet."),
        ("unsupported url", "Link não suportado."),
        ("http error 404", "Link não encontrado (404)."),
        ("unable to download webpage", "Não foi possível abrir o link."),
    ]
    for trecho, amigavel in traducoes:
        if trecho in baixo:
            return amigavel
    return texto.split("\n")[0][:200]


def listar_itens(url: str) -> list[ItemFila]:
    """Expande um link em itens: 1 item para vídeo, N itens para playlist."""
    logger = _Logger()
    opcoes = _opcoes_base(logger) | {"extract_flat": True, "ignoreerrors": True}
    try:
        with yt_dlp.YoutubeDL(opcoes) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception as e:  # noqa: BLE001 - qualquer falha vira mensagem para o usuário
        raise ErroLeitura(mensagem_amigavel(str(e))) from e

    if not info:
        raise ErroLeitura(mensagem_amigavel(logger.ultimo_erro))

    if info.get("_type") == "playlist" or "entries" in info:
        itens = []
        for entrada in info.get("entries") or []:
            if not entrada:
                continue
            link = entrada.get("url") or entrada.get("webpage_url")
            titulo = entrada.get("title") or link
            if not link or str(titulo).lower() in TITULOS_INVALIDOS:
                continue
            itens.append(ItemFila(titulo=titulo, url=link))
        return itens

    return [ItemFila(titulo=info.get("title") or url, url=info.get("webpage_url") or url)]


def _montar_pos_processadores(qualidade: str, capa_e_metadados: bool) -> list[dict]:
    pos = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": qualidade}]
    if capa_e_metadados:
        pos.append({"key": "FFmpegMetadata", "add_metadata": True})
        pos.append({"key": "EmbedThumbnail", "already_have_thumbnail": False})
    return pos


def _apagar_temporarios(arquivos: set[str]) -> None:
    for nome in arquivos:
        for candidato in (Path(nome), Path(nome + ".part"), Path(nome + ".ytdl")):
            try:
                if candidato.is_file():
                    candidato.unlink()
            except OSError:
                log.debug("Não consegui apagar %s", candidato, exc_info=True)


def baixar_mp3(
    url: str,
    pasta: str | Path,
    *,
    qualidade: str = "192",
    capa_e_metadados: bool = True,
    pular_existentes: bool = True,
    ao_progresso: Callable[[Etapa, Optional[float]], None] | None = None,
    ao_titulo: Callable[[str], None] | None = None,
    motivo_parada: Callable[[], Optional[str]] | None = None,
) -> Resultado:
    """Baixa UMA música e converte para MP3.

    `motivo_parada()` deve devolver None para continuar, ou "pular"/"cancelar".
    Nunca lança exceção: sempre devolve um `Resultado`.
    """
    if not localizar_ffmpeg():
        return Resultado(Status.ERRO, mensagem="FFmpeg não encontrado. Veja o README.")

    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    logger = _Logger()
    temporarios: set[str] = set()
    titulo = ""

    def avisar(etapa: Etapa, fracao: Optional[float] = None) -> None:
        if ao_progresso:
            ao_progresso(etapa, fracao)

    def checar_parada() -> None:
        motivo = motivo_parada() if motivo_parada else None
        if motivo:
            raise Interrompido(motivo)

    def hook_download(d: dict) -> None:
        checar_parada()
        for chave in ("tmpfilename", "filename"):
            if d.get(chave):
                temporarios.add(d[chave])
        if d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            baixado = d.get("downloaded_bytes") or 0
            avisar(Etapa.BAIXANDO, min(baixado / total, 1.0) if total else None)
        elif d.get("status") == "finished":
            avisar(Etapa.CONVERTENDO)

    def hook_pos(d: dict) -> None:
        if d.get("status") != "started":
            return
        checar_parada()
        nome = d.get("postprocessor")
        if nome == "ExtractAudio":
            avisar(Etapa.CONVERTENDO)
        elif nome in ("Metadata", "EmbedThumbnail"):
            avisar(Etapa.FINALIZANDO)

    opcoes = _opcoes_base(logger) | {
        "format": "bestaudio/best",
        "outtmpl": {"default": str(pasta / "%(title)s.%(ext)s")},
        "noplaylist": True,
        "ignoreerrors": False,
        "writethumbnail": capa_e_metadados,
        "postprocessors": _montar_pos_processadores(qualidade, capa_e_metadados),
        "progress_hooks": [hook_download],
        "postprocessor_hooks": [hook_pos],
    }

    try:
        with yt_dlp.YoutubeDL(opcoes) as ydl:
            info = ydl.extract_info(url, download=False)
            if info and (info.get("_type") == "playlist" or "entries" in info):
                # Buscas ("ytsearch1:...") voltam como uma playlist de 1 item
                entradas = [e for e in (info.get("entries") or []) if e]
                info = entradas[0] if entradas else None
            if not info:
                return Resultado(Status.ERRO, mensagem="Nenhum resultado encontrado.")

            titulo = info.get("title") or ""
            if ao_titulo and titulo:
                ao_titulo(titulo)

            destino = Path(ydl.prepare_filename(info)).with_suffix(".mp3")
            if pular_existentes and destino.exists():
                return Resultado(Status.JA_EXISTE, titulo, destino, "Já estava na pasta.")

            checar_parada()
            avisar(Etapa.BAIXANDO, 0.0)
            info = ydl.process_ie_result(info, download=True)

        downloads = (info or {}).get("requested_downloads") or [{}]
        caminho = Path(downloads[-1].get("filepath") or destino)
        return Resultado(Status.OK, titulo, caminho)

    except Interrompido as e:
        _apagar_temporarios(temporarios)
        status = Status.PULADO if e.motivo == "pular" else Status.CANCELADO
        return Resultado(status, titulo)
    except DownloadError as e:
        _apagar_temporarios(temporarios)
        return Resultado(Status.ERRO, titulo, mensagem=mensagem_amigavel(logger.ultimo_erro or str(e)))
    except Exception as e:  # noqa: BLE001
        log.exception("Falha inesperada baixando %s", url)
        _apagar_temporarios(temporarios)
        return Resultado(Status.ERRO, titulo, mensagem=mensagem_amigavel(str(e)))
