"""Orquestra a fila de downloads/conversões e avisa a interface por eventos.

O gerenciador roda numa thread separada e NUNCA mexe na interface diretamente:
ele só chama `emitir(evento)`. A interface coloca os eventos numa fila e os
consome na thread principal (o Tkinter não é thread-safe).
"""

from __future__ import annotations

import logging
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Callable, Optional

from nucleo import conversor, youtube
from nucleo.entrada import interpretar_entrada
from nucleo.ferramentas import localizar_ffmpeg
from nucleo.youtube import Etapa, ItemFila, Resultado, Status

log = logging.getLogger(__name__)


class TipoEvento(Enum):
    MENSAGEM = auto()  # texto no rodapé
    FILA = auto()  # lista completa de títulos (cria as linhas "Na fila")
    INICIO_ITEM = auto()
    TITULO_ITEM = auto()  # título real descoberto (ex.: resultado de uma busca)
    PROGRESSO_ITEM = auto()
    FIM_ITEM = auto()
    FIM = auto()  # acabou tudo; `mensagem` traz o resumo


@dataclass
class Evento:
    tipo: TipoEvento
    indice: int = 0
    total: int = 0
    titulo: str = ""
    etapa: Optional[Etapa] = None
    progresso: Optional[float] = None
    resultado: Optional[Resultado] = None
    mensagem: str = ""
    titulos: list[str] = field(default_factory=list)


Emissor = Callable[[Evento], None]


@dataclass
class OpcoesDownload:
    pasta: str
    qualidade: str = "192"
    capa_e_metadados: bool = True
    pular_existentes: bool = True


def montar_resumo(contagem: Counter, erros_leitura: int = 0) -> str:
    partes = []
    if contagem[Status.OK]:
        partes.append(f"✅ {contagem[Status.OK]} concluída(s)")
    if contagem[Status.JA_EXISTE]:
        partes.append(f"📁 {contagem[Status.JA_EXISTE]} já existia(m)")
    if contagem[Status.PULADO]:
        partes.append(f"⏭ {contagem[Status.PULADO]} pulada(s)")
    if contagem[Status.CANCELADO]:
        partes.append(f"⛔ {contagem[Status.CANCELADO]} cancelada(s)")
    erros = contagem[Status.ERRO] + erros_leitura
    if erros:
        partes.append(f"❌ {erros} com erro")
    return " · ".join(partes) if partes else "Nada foi processado."


class Gerenciador:
    def __init__(self, emitir: Emissor) -> None:
        self._emitir = emitir
        self._pular = threading.Event()
        self._cancelar = threading.Event()
        self._ocupado = threading.Lock()

    # ---- controle vindo da interface -------------------------------------
    @property
    def ocupado(self) -> bool:
        return self._ocupado.locked()

    def pular_atual(self) -> None:
        self._pular.set()

    def cancelar_tudo(self) -> None:
        self._cancelar.set()

    def _motivo_parada(self) -> Optional[str]:
        if self._cancelar.is_set():
            return "cancelar"
        if self._pular.is_set():
            return "pular"
        return None

    def _progresso_limitado(self, indice: int) -> Callable[[Etapa, Optional[float]], None]:
        """Evita inundar a interface: no máximo ~10 atualizações/s por item."""
        ultimo = {"t": 0.0, "etapa": None}

        def enviar(etapa: Etapa, fracao: Optional[float]) -> None:
            agora = time.monotonic()
            if etapa == ultimo["etapa"] and agora - ultimo["t"] < 0.1 and fracao not in (0.0, 1.0):
                return
            ultimo.update(t=agora, etapa=etapa)
            self._emitir(Evento(TipoEvento.PROGRESSO_ITEM, indice=indice, etapa=etapa, progresso=fracao))

        return enviar

    # ---- downloads --------------------------------------------------------
    def baixar(self, entrada: str, opcoes: OpcoesDownload) -> None:
        """Ponto de entrada da thread de download."""
        with self._ocupado:
            self._pular.clear()
            self._cancelar.clear()
            try:
                self._baixar(entrada, opcoes)
            except Exception as e:  # noqa: BLE001 - a thread nunca pode morrer calada
                log.exception("Erro inesperado no gerenciador")
                self._emitir(Evento(TipoEvento.FIM, mensagem=f"❌ Erro inesperado: {e}"))

    def _baixar(self, entrada: str, opcoes: OpcoesDownload) -> None:
        if not localizar_ffmpeg():
            self._emitir(Evento(TipoEvento.FIM, mensagem="❌ FFmpeg não encontrado. Veja a Ajuda (?) ou o README."))
            return

        try:
            alvos = interpretar_entrada(entrada)
        except ValueError as e:
            self._emitir(Evento(TipoEvento.FIM, mensagem=f"⚠️ {e}"))
            return
        if not alvos:
            self._emitir(Evento(TipoEvento.FIM, mensagem="⚠️ Digite um link, um nome de música ou importe um .txt."))
            return

        fila: list[ItemFila] = []
        erros_leitura = 0
        for n, alvo in enumerate(alvos, start=1):
            if self._cancelar.is_set():
                break
            if alvo.eh_busca:
                fila.append(ItemFila(titulo=alvo.texto, url=alvo.url))
                continue
            self._emitir(Evento(TipoEvento.MENSAGEM, mensagem=f"🔎 Lendo link {n}/{len(alvos)}..."))
            try:
                fila.extend(youtube.listar_itens(alvo.url))
            except youtube.ErroLeitura as e:
                erros_leitura += 1
                self._emitir(Evento(TipoEvento.MENSAGEM, mensagem=f"❌ {alvo.texto[:60]}: {e}"))

        if not fila:
            msg = "⛔ Cancelado." if self._cancelar.is_set() else "❌ Nenhuma música encontrada."
            self._emitir(Evento(TipoEvento.FIM, mensagem=msg))
            return

        total = len(fila)
        self._emitir(Evento(TipoEvento.FILA, total=total, titulos=[i.titulo for i in fila]))

        contagem: Counter = Counter()
        for indice, item in enumerate(fila):
            if self._cancelar.is_set():
                resultado = Resultado(Status.CANCELADO, item.titulo)
            else:
                self._pular.clear()
                self._emitir(Evento(TipoEvento.INICIO_ITEM, indice=indice, total=total, titulo=item.titulo))
                resultado = youtube.baixar_mp3(
                    item.url,
                    opcoes.pasta,
                    qualidade=opcoes.qualidade,
                    capa_e_metadados=opcoes.capa_e_metadados,
                    pular_existentes=opcoes.pular_existentes,
                    ao_progresso=self._progresso_limitado(indice),
                    ao_titulo=lambda t, i=indice: self._emitir(Evento(TipoEvento.TITULO_ITEM, indice=i, titulo=t)),
                    motivo_parada=self._motivo_parada,
                )
            contagem[resultado.status] += 1
            self._emitir(Evento(TipoEvento.FIM_ITEM, indice=indice, total=total, resultado=resultado))

        self._emitir(Evento(TipoEvento.FIM, mensagem=montar_resumo(contagem, erros_leitura)))

    # ---- conversão de arquivos locais ------------------------------------
    def converter(self, arquivos: list[str], pasta_destino: Optional[str], qualidade: str) -> None:
        with self._ocupado:
            self._pular.clear()
            self._cancelar.clear()
            try:
                self._converter(arquivos, pasta_destino, qualidade)
            except Exception as e:  # noqa: BLE001
                log.exception("Erro inesperado na conversão")
                self._emitir(Evento(TipoEvento.FIM, mensagem=f"❌ Erro inesperado: {e}"))

    def _converter(self, arquivos: list[str], pasta_destino: Optional[str], qualidade: str) -> None:
        if not localizar_ffmpeg():
            self._emitir(Evento(TipoEvento.FIM, mensagem="❌ FFmpeg não encontrado. Veja a Ajuda (?) ou o README."))
            return

        total = len(arquivos)
        self._emitir(Evento(TipoEvento.FILA, total=total, titulos=[Path(a).name for a in arquivos]))
        contagem: Counter = Counter()

        for indice, arquivo in enumerate(arquivos):
            nome = Path(arquivo).name
            if self._cancelar.is_set():
                resultado = Resultado(Status.CANCELADO, nome)
            elif self._pular.is_set():
                self._pular.clear()
                resultado = Resultado(Status.PULADO, nome)
            else:
                self._emitir(Evento(TipoEvento.INICIO_ITEM, indice=indice, total=total, titulo=nome))
                self._emitir(Evento(TipoEvento.PROGRESSO_ITEM, indice=indice, etapa=Etapa.CONVERTENDO))
                try:
                    caminho = conversor.converter_para_mp3(arquivo, pasta_destino, qualidade)
                    resultado = Resultado(Status.OK, nome, caminho)
                except FileExistsError as e:
                    resultado = Resultado(Status.JA_EXISTE, nome, Path(str(e)), "O MP3 já existia.")
                except conversor.ErroConversao as e:
                    resultado = Resultado(Status.ERRO, nome, mensagem=str(e))
            contagem[resultado.status] += 1
            self._emitir(Evento(TipoEvento.FIM_ITEM, indice=indice, total=total, resultado=resultado))

        self._emitir(Evento(TipoEvento.FIM, mensagem=montar_resumo(contagem)))
