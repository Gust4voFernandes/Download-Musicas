"""Núcleo do Baixador de Músicas: tudo que NÃO depende da interface gráfica."""

__version__ = "4.0.0"
NOME_APP = "Baixador de Músicas"
