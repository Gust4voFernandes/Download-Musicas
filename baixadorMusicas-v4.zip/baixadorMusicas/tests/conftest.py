import sys
from pathlib import Path

# Permite "import nucleo" rodando o pytest a partir da raiz do projeto
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
