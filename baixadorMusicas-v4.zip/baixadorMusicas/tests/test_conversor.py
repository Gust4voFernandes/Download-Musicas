import subprocess

import pytest

from nucleo.conversor import ErroConversao, converter_para_mp3, destino_mp3
from nucleo.ferramentas import localizar_ffmpeg

FFMPEG = localizar_ffmpeg()
precisa_ffmpeg = pytest.mark.skipif(not FFMPEG, reason="FFmpeg não disponível")


def _gerar_wav(caminho):
    subprocess.run(
        [FFMPEG, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1",
         str(caminho)],
        check=True,
    )


def test_destino_nao_sobrescreve_a_propria_origem(tmp_path):
    origem = tmp_path / "musica.mp3"
    assert destino_mp3(origem).name == "musica (convertido).mp3"


@precisa_ffmpeg
def test_converte_wav_para_mp3(tmp_path):
    wav = tmp_path / "teste.wav"
    _gerar_wav(wav)
    mp3 = converter_para_mp3(wav, qualidade="128")
    assert mp3.suffix == ".mp3" and mp3.stat().st_size > 1000


@precisa_ffmpeg
def test_nao_sobrescreve_sem_permissao(tmp_path):
    wav = tmp_path / "teste.wav"
    _gerar_wav(wav)
    converter_para_mp3(wav)
    with pytest.raises(FileExistsError):
        converter_para_mp3(wav)


@precisa_ffmpeg
def test_arquivo_invalido_gera_erro(tmp_path):
    ruim = tmp_path / "ruim.mp4"
    ruim.write_text("isto não é um vídeo")
    with pytest.raises(ErroConversao):
        converter_para_mp3(ruim)
    assert not (tmp_path / "ruim.mp3").exists()
