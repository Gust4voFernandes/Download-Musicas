from collections import Counter

from nucleo.gerenciador import montar_resumo
from nucleo.youtube import Status, _montar_pos_processadores, mensagem_amigavel


def test_pos_processadores_sempre_convertem_para_mp3():
    pos = _montar_pos_processadores("320", capa_e_metadados=False)
    assert pos == [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "320"}]


def test_pos_processadores_com_capa():
    chaves = [p["key"] for p in _montar_pos_processadores("192", capa_e_metadados=True)]
    assert chaves == ["FFmpegExtractAudio", "FFmpegMetadata", "EmbedThumbnail"]


def test_mensagens_amigaveis():
    assert "privado" in mensagem_amigavel("ERROR: [youtube] abc: Private video. Sign in")
    assert "idade" in mensagem_amigavel("Sign in to confirm your age")
    assert "403" in mensagem_amigavel("ERROR: unable to download video data: HTTP Error 403: Forbidden")
    assert mensagem_amigavel(None) == "Erro desconhecido."


def test_resumo():
    c = Counter({Status.OK: 3, Status.ERRO: 1, Status.JA_EXISTE: 2})
    resumo = montar_resumo(c)
    assert "3 concluída" in resumo and "2 já existia" in resumo and "1 com erro" in resumo
