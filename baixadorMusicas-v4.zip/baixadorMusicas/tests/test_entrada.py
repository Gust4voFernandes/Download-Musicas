import pytest

from nucleo.entrada import (
    eh_url,
    interpretar_entrada,
    interpretar_linha,
    ler_lista_txt,
    tratar_link_youtube,
)


@pytest.mark.parametrize(
    "texto, esperado",
    [
        ("https://www.youtube.com/watch?v=abc", True),
        ("youtu.be/abc", True),
        ("www.youtube.com/watch?v=abc", True),
        ("https://soundcloud.com/artista/musica", True),
        ("Guns N Roses - Patience", False),
        ("AC/DC - Thunderstruck", False),
    ],
)
def test_eh_url(texto, esperado):
    assert eh_url(texto) is esperado


def test_playlist_normal_vira_playlist_completa():
    url = "https://www.youtube.com/watch?v=abc123&list=PLxyz&index=3"
    assert tratar_link_youtube(url) == "https://www.youtube.com/playlist?list=PLxyz"


def test_youtube_music_mantem_host():
    url = "https://music.youtube.com/watch?v=abc&list=OLAK5uy_123"
    assert tratar_link_youtube(url) == "https://music.youtube.com/playlist?list=OLAK5uy_123"


def test_mix_rd_baixa_so_o_video():
    url = "https://www.youtube.com/watch?v=abc123&list=RDabc123&start_radio=1"
    assert tratar_link_youtube(url) == "https://www.youtube.com/watch?v=abc123"


def test_mix_rd_em_link_curto():
    assert tratar_link_youtube("https://youtu.be/abc123?list=RDabc123") == "https://www.youtube.com/watch?v=abc123"


def test_link_sem_lista_nao_muda():
    url = "https://www.youtube.com/watch?v=abc123"
    assert tratar_link_youtube(url) == url


def test_link_de_outro_site_nao_muda():
    url = "https://soundcloud.com/a/b?list=123"
    assert tratar_link_youtube(url) == url


def test_nome_vira_busca():
    alvo = interpretar_linha("  Legião Urbana - Tempo Perdido ")
    assert alvo.eh_busca
    assert alvo.url == "ytsearch1:Legião Urbana - Tempo Perdido"


def test_link_sem_https_ganha_esquema():
    alvo = interpretar_linha("youtu.be/abc")
    assert not alvo.eh_busca
    assert alvo.url == "https://youtu.be/abc"


def test_ler_txt_utf8_com_bom_comentarios_e_duplicadas(tmp_path):
    arq = tmp_path / "lista.txt"
    arq.write_bytes("\ufeffMúsica 1\n\n# comentário\nmúsica 1\nhttps://youtu.be/x\n".encode("utf-8"))
    assert ler_lista_txt(arq) == ["Música 1", "https://youtu.be/x"]


def test_ler_txt_ansi_do_bloco_de_notas(tmp_path):
    arq = tmp_path / "lista.txt"
    arq.write_bytes("Canção do Exílio\n".encode("cp1252"))
    assert ler_lista_txt(arq) == ["Canção do Exílio"]


def test_entrada_mistura_texto_e_txt(tmp_path):
    arq = tmp_path / "lista.txt"
    arq.write_text("Musica A\nhttps://youtu.be/x\n", encoding="utf-8")
    alvos = interpretar_entrada(f"Musica B\n\"{arq}\"\nMusica A")
    assert [a.texto for a in alvos] == ["Musica B", "Musica A", "https://youtu.be/x"]


def test_txt_inexistente_gera_erro_claro():
    with pytest.raises(ValueError, match="não encontrado"):
        interpretar_entrada("C:/nao/existe/lista.txt")


def test_entrada_vazia():
    assert interpretar_entrada("   \n\n") == []
