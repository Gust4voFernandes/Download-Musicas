@echo off
REM Gera dist\DownloaderMusic.exe. Rode dentro da pasta do projeto.
REM   build.bat        -> exe completo (FFmpeg + Deno embutidos)
REM   build.bat leve   -> exe sem Deno (menor, mas o YouTube pode falhar mais)
setlocal
if not exist .venv (
    echo [1/5] Criando ambiente virtual...
    python -m venv .venv || goto :erro
)
call .venv\Scripts\activate.bat || goto :erro
echo [2/5] Instalando dependencias...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements-dev.txt || goto :erro
echo [3/5] Rodando testes...
python -m pytest -q || goto :erro
echo [4/5] Preparando binarios em vendor\...
if not exist vendor mkdir vendor
if /I "%1"=="leve" (
    if exist vendor\deno.exe del vendor\deno.exe
) else (
    if not exist vendor\deno.exe if exist .venv\Scripts\deno.exe copy /Y .venv\Scripts\deno.exe vendor\ >nul
)
echo [5/5] Empacotando com PyInstaller...
python -m PyInstaller --noconfirm --clean DownloaderMusic.spec || goto :erro
echo.
echo Pronto! Executavel em: dist\DownloaderMusic.exe
exit /b 0
:erro
echo.
echo *** Falhou. Veja as mensagens acima. ***
exit /b 1
