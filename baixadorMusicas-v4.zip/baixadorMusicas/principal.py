"""Ponto de entrada: configura o log e abre a janela."""

import logging
from logging.handlers import RotatingFileHandler

from nucleo.ferramentas import pasta_de_configuracao


def configurar_log() -> None:
    arquivo = pasta_de_configuracao() / "baixador.log"
    manipulador = RotatingFileHandler(arquivo, maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    manipulador.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[manipulador])


def main() -> None:
    configurar_log()
    from interface.tela import App  # importado depois do log para registrar erros de import

    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
